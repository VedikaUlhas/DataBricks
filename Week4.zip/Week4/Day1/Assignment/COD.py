import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("sales_data.csv")
print(df.head())

plt.figure(figsize=(7,4))

df.groupby("Product")["UnitSold"].sum().plot(kind="bar",color="skyblue")

plt.title("Total Units Sold per product")
plt.xlabel("Products")
plt.ylabels("Units Sold")

plt.savefig("units_sold_barplot.png")
plt.show()

plt.figure(figsize=(7,4))

df["Date"]=pd.to_datetime(df{"Date"})
df_sorted =df.sorted_values("Date")

plt.plot(df_sorted["Date"],df_sorted["Revenue"],marker="o")

plt.title("Daily Revenue Trend")
plt.xlabel("Date")
plt.ylabel("Revenue")

plt.savefig("revenue_lineplot.png")
plt.show()

plt.figure(figsize=(7,4))

plt.scatter(df["UnitsSold"],df{"Revenue"},color="orange")
plt.title("Units Sold vs Revenue")
plt.xlabel("units Sold")
plt.ylabel("Revenue")

plt.savefig("Units_vs_revenue_scatter.png")
plt.show()