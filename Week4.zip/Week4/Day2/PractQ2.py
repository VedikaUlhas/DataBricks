
class HospitalPatientTracker:

    def register_patient(self,inventory:dict,patient_id:str,age:int,blood_pressure:int)->dict:
        if patient_id in inventory:
            raise ValueError("Patient ID already exists.")
        inventory[patient_id] = [age,blood_pressure]
        return inventory
    
    def update_vitals(self,inventory:dict,patient_id:str,new_age:int,new_bp:int)->dict:
        if patient_id not in inventory:
            raise KeyError("Patient Not Found")
        inventory[patient_id]=[new_age,new_bp]
        return inventory 
    
    def get_patient_age(self,inventory:dict,patient_id:str)->int:
        if patient_id not in inventory:
            raise KeyError("Patient Not Found")
        return inventory[patient_id][0]


h=HospitalPatientTracker()
d = h.register_patient({},"P101",45,120)
print("Original Dict:")
print(d)
ud = h.update_vitals({'P101':[45,120]},"P101",46,130)
print("Updated Dict:")
print(ud)
age =h.get_patient_age(ud,"P101")
print("Age is ",age)