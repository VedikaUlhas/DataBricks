import pandas as pd
class ECommerceAnalyzer:

    def create_transaction_log_df(Self,transaction_log:list) -> pd.DataFrame:
        columns = ["OrderID","ProductID","Amount","City"]
        df = pd.DataFrame(transaction_log,columns = columns)
        return df
    
    def create_product_master_df(self,product_master:list)->pd.DataFrame:
        columns = ["ProductID","ProductName"]
        pdf = pd.DataFrame(product_master,columns = columns)
        return pdf
    
    def merge_product_names(self,transaction_df:pd.DataFrame,product_master_df:pd.DataFrame) -> pd.DataFrame:
        merged = pd.merge(transaction_df,product_master_df,on="ProductID",how = "left")
        return merged
    
    def total_sales_by_city(self,merged:pd.DataFrame)->pd.DataFrame:
        totalSale = merged.groupby("City")["Amount"].sum().rename("Total Sales")
        totalSale=totalSale.reset_index()
        return totalSale

transaction_log = [
    [101,"P001",500,"Mumbai"],
    [102,"P002",1200,"Delhi"],
    [103,"P001",500,"Mumbai"]
]

product_master = [
    ["P001","Laptop"],
    ["P002","Mobile"]
]

e = ECommerceAnalyzer()
transaction_df = e.create_transaction_log_df(transaction_log)
print(transaction_df)
product_master_df = e.create_product_master_df(product_master)
print(product_master_df)
merged_df = e.merge_product_names(transaction_df,product_master_df)
print(merged_df)
totSale = e.total_sales_by_city(merged_df)
print(totSale)