import pandas as pd
class WarehouseInventoryTracker:

    def create_stock_log_df(Self,stock_log:list) -> pd.DataFrame:
        columns = ["ItemID","WarehouseLocation","StockLevel","LastCheckedDate"]
        df = pd.DataFrame(stock_log,columns=columns)
        return df
    
    def filter_low_stock(self,stock_df:pd.DataFrame,threshold:int)->pd.DataFrame:
        df = stock_df[stock_df["StockLevel"]<threshold]
        return df
    
    def highest_stock_location(self,stock_df: pd.DataFrame) -> pd.DataFrame:
        hts = stock_df.groupby("WarehouseLocation")["StockLevel"].sum().rename("TotalStock")
        hts = hts.reset_index()
        shts = hts.sort_values(by="TotalStock",ascending=False).head(1)
        return shts

stock_log = [
    ["A001","Zone A",150,"2025-11-20"],
    ["B002","Zone B",5,"2025-11-21"]
]

w = WarehouseInventoryTracker()
stock_df = w.create_stock_log_df(stock_log)
print(stock_df)
tdf = w.filter_low_stock(stock_df,10)
print(tdf)
high = w.highest_stock_location(stock_df)
print(high)