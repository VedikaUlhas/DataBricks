file = open("example.txt", "w")
file.write("Hello, File Handling in Python!\n")
file.write("This is the second line\n")

file.close()

file=open("example.txt","r")

print(file.read())

file.close()

file = open("example.txt","a")
file.write("This line is appended.\n")
file.close()

file = open("example.txt","r")
for line in file:
    print(line.strip())
file.close()

file = open("example.txt","r")
lines= file.readlines()
print(lines)
file.close()

import os

print(os.getcwd())
os.mkdir("data")
with open("data/info.txt","w") as file:
    file.write("File inside data folder.\n")

print(os.path.exists("data/info.txt"))
print(os.listdir("data"))

try:
    with open("non_existing.txt","r") as file:
        print(file.read())
except FileNotFoundError:
    print("File not found!")

try:
    with open("/root/secure.txt","r" ) as file:
        print(file.read())
except PermissionError:
    print("Permission denied.")












import pandas as pd

class AttendanceAnalyzer:

    def create_attendance_df(self,data:list) -> pd.DataFrame:
        df = pd.DataFrame(data,columns=["EmployeeID","Department","Date","Attendance"])
        df["Date"] = df["Date"].astype(str)
        return df
    
    def compute_monthly_attendance_rate(self,df:pd.DataFrame) -> pd.DataFrame:
       

        df=df.copy()
        df['Month'] = df["Date"].str[:7]  
        total_df = (df.groupby(['EmployeeID', 'Month']).size().reset_index(name='Total'))
        present_df = (df[df['Attendance'] == 'Present'].groupby(['EmployeeID', 'Month']).size().reset_index(name='Present'))
        attendance_df = pd.merge(total_df, present_df, on=['EmployeeID', 'Month'], how='left').fillna(0)
        # attendance_df["Present"] = attendance_df["Present"]

        attendance_df['Attendance Rate'] = (attendance_df['Present'] / attendance_df['Total']) * 100
        return attendance_df[["EmployeeID","Month","Attendance Rate"]]
    
        
        


    def add_absence_flag(self,df:pd.DataFrame)->pd.DataFrame:
        
        df["IsAbsent"] = (df["Attendance"] == "Absent").astype(int)
        return df

        


    def high_absentees(self,df:pd.DataFrame, threshold: int)-> pd.DataFrame:
        df_absent = df[df["Attendance"] == "Absent"]        
        absence_count = df_absent.groupby("EmployeeID").size().reset_index(name="Absence Count")
        absent_df = absence_count[absence_count["Absence Count"] > threshold]
        return absent_df




    def department_attendance_summary(self, df: pd.DataFrame) -> pd.DataFrame:


        #  one method
        crosss = pd.crosstab(df["Department"],df["Attendance"], colnames=[None]) 
        crosss = crosss.reindex(columns=["Present","Absent","Leave"],fill_value=0)
        return crosss.reset_index()

        # 2nd method
        # tab = pd.crosstab(df["Department"],df["Attendance"])
        # tab.columns.name = None

        # for col in ["Present","Absent","Leave"]:
        #     if col not in tab.columns:
        #         tab[col] = 0

        # tab = tab[["Present","Absent","Leave"]]
        # return tab.reset_index()

