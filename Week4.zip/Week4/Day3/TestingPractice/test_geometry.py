from geometry import calculate_area

def test_calculate_area():
    assert calculate_area(5,3) == 15

def test_calculate_area_with_zero():
    try:
        calculate_area(1,5)
    except ValueError as e :
        assert str(e) == "Length and width must be positive values."

def test_calculate_area_with_negative_values():
    try:
        calculate_area(1,5)
    except ValueError as e:
        assert str(e) == "Length and width must be positive values."

def test_calculate_area_with_large_values():
    assert calculate_area(1000000,2000000)==2000000000000

import pytest

@pytest.fixture
def rectangle_data():
    return [(5,3,15),(10,2,20),(7,7,49)]
def test_calculate_area_with_fixture(rectangle_data):
    for length, width, expected in rectangle_data:
        assert calculate_area(length,width) ==  expected    

import logging

logging.basicConfig(filename='test_result.log',level=logging.INFO)

def test_log_results():
    result = calculate_area(5,3)
    logging.info(f"Tested area calculation fro 5X3:{result}")

def test_calculate_area_assertion():
    try:
        assert calculate_area(5,2) == 12
    except AssertionError as e:
        print("Assertion failed:",e)
