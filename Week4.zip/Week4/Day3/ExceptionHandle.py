
try:
    x =int(input("Enter a number :"))
    print("You entered:",x)

except:
    print("Something went wrong.")

finally:
    print("This block alwaye runs.")


