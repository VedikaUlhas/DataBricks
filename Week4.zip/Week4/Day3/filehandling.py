
# from datetime import datetime

# headline = "Breaking News: Pythion becomes the most used programming language!"
# timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# with open("news.txt","w") as f:
#     f.write(f"Timestamp :{timestamp}\n")
#     f.write(headline)

# with open("news.txt","r") as f:
#     print(f.read())


# import json 
# weather_data = {
#     "location":"New Delhi",
#     "temperature_c":32.5,
#     "condition":"Partly Cloudy",
#     "humidity":54,
#     "last_updated":"2025-02-01 10:30"
# }

# with open("weather.json","w") as f:
#     json.dump(weather_data,f,indent=4)

# with open("weather.json","r") as f:
#     data = json.load(f)
#     print("Weather in",data["location"])
#     print("Temperature:",data["temperature_c"])

import xml.etree.ElementTree as ET

root = ET.Element("catalog")

prod1 = ET.SubElement(root,"product")
ET.SubElement(prod1,"name").text = "Laptop"
ET.SubElement(prod1,"price").text = "82000"
ET.SubElement(prod1,"brand").text = "TechPro"

prod1 = ET.SubElement(root,"product")
ET.SubElement(prod1,"name").text = "Smartphone"
ET.SubElement(prod1,"price").text = "45000"
ET.SubElement(prod1,"brand").text = "MobileMax"

tree=ET.ElementTree(root)
tree.write("products.xml")

tree=ET.parse("products.xml")
root = tree.getroot()

for product in root:
    name = product.find("name").text
    price = product.find("price").text
    print(f"Product:{name} | Price:{price}")
    