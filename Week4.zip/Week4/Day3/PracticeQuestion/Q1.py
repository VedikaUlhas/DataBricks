import pandas as pd

def create_watch_df(watch_data:list)->pd.DataFrame:
    columns = ["UserID","MovieName","WatchMinutes","Genre"]
    df = pd.DataFrame(watch_data,columns=columns)
    return df

watch_data = [
    [101,"Inception",120,"Sci_Fi"],
    [102,"Dangal",160,"Drama"],
    [101,"Interstellar",150,"Sci_Fi"]
]

wdf=create_watch_df(watch_data)
# print(wdf)

def create_user_profile_df(profile_date:list)->pd.DataFrame:
    columns = ["UserID","UserName","SubscriptionType"]
    pdf = pd.DataFrame(profile_date,columns=columns)
    return pdf

profile_data = [
    [101,"Neha","Premium"],
    [102,"Karan","Basic"]
]

udf=create_user_profile_df(profile_data)
# print(udf)

def merged_profile_info(workout_df:pd.DataFrame,profile_df:pd.DataFrame)->pd.DataFrame:
    merged = pd.merge(workout_df,profile_df,on="UserID")
    return merged

mdf = merged_profile_info(wdf,udf)
print(mdf)

def get_heavy_viewers(watch_df:pd.DataFrame)->pd.DataFrame:
    ct = watch_df.groupby(["UserID"]).size().rename("Count")
    ct=ct.reset_index()
    return ct[ct["Count"]>1]

# print(get_heavy_viewers(wdf))

def calculate_total_watch_time(watch_df:pd.DataFrame) -> pd.DataFrame:
    wtdf = watch_df.groupby(["UserID"])["WatchMinutes"].sum().rename("TotalMinutes")
    wtdf =wtdf.reset_index()
    return wtdf

# print(calculate_total_watch_time(wdf))

def subscription_wise_users(merged_df:pd.DataFrame)->pd.DataFrame:
    udf = merged_df.groupby(["SubscriptionType"])["UserID"].size().reset_index("UniqueUsers")
    return udf

print(subscription_wise_users(mdf))
