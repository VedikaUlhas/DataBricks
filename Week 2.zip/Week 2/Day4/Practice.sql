---------------------------------------------------
-- 1️⃣ SCHEMA CREATION
---------------------------------------------------
create database day2_4;
use day2_4;

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS sales_rep;

CREATE TABLE customers (
   customer_id INT PRIMARY KEY,
   customer_name VARCHAR(100),
   city VARCHAR(50)
);

CREATE TABLE categories (
   category_id INT PRIMARY KEY,
   category_name VARCHAR(50)
);

CREATE TABLE products (
   product_id INT PRIMARY KEY,
   product_name VARCHAR(100),
   category_id INT REFERENCES categories(category_id),
   price DECIMAL(10,2)
);

CREATE TABLE sales_rep (
   rep_id INT PRIMARY KEY,
   rep_name VARCHAR(100),
   region VARCHAR(50)
);

CREATE TABLE orders (
   order_id INT PRIMARY KEY,
   customer_id INT REFERENCES customers(customer_id),
   rep_id INT REFERENCES sales_rep(rep_id),
   order_date DATE
);

CREATE TABLE order_items (
   item_id INT PRIMARY KEY,
   order_id INT REFERENCES orders(order_id),
   product_id INT REFERENCES products(product_id),
   quantity INT
);

---------------------------------------------------
-- 2️⃣ INSERT SAMPLE DATA
---------------------------------------------------
INSERT INTO customers VALUES
(1,'Alice','Delhi'),
(2,'Bob','Mumbai'),
(3,'Charlie','Delhi'),
(4,'David','Chennai');

INSERT INTO categories VALUES
(10,'Electronics'),
(20,'Furniture');

INSERT INTO products VALUES
(101,'Laptop',10,55000),
(102,'Mobile',10,15000),
(103,'Chair',20,3000),
(104,'Table',20,7000);

INSERT INTO sales_rep VALUES
(1,'Ravi','North'),
(2,'Neha','South');

INSERT INTO orders VALUES
(201,1,1,'2025-01-10'),
(202,2,1,'2025-01-12'),
(203,3,2,'2025-01-15'),
(204,1,1,'2025-01-20'),
(205,4,2,'2025-01-22');

INSERT INTO order_items VALUES
(1,201,101,1),
(2,201,103,2),
(3,202,102,3),
(4,203,104,1),
(5,204,101,2),
(6,205,102,1);


-- -------------------------------------------------
-- ⭐ EASY QUERIES (1–5)
-- -------------------------------------------------

-- 1) Total orders per city 
select c.city,count(o.order_id) as no_of_orders
from orders o
join customers c on o.customer_id = c.customer_id
group by c.city;

-- 2) List products costing above 10000 sorted by price
select * from products 
where price>10000
order by price desc;

-- 3) Show customers from Delhi only
select * from customers where city ='Delhi';

-- 4) Show each product’s total quantity sold
select p.product_id,p.product_name,sum(o.quantity)
from products p
join order_items o on p.product_id = o.product_id
group by product_id;

-- 5) Show reps who handled at least 2 orders
select r.rep_id,count(o.order_id) as tOrd
from sales_rep r
join orders o on r.rep_id=o.rep_id
group by r.rep_id
having tOrd >2;

-- 6. Customers who placed more than 2 orders
select c.customer_id,c.customer_name,count(o.order_id) as tCount
from customers c
join orders o on o.customer_id = c.customer_id
group by c.customer_id
having tCount >2;

-- 7.Total revenue per order
select o.order_id, sum(o.quantity * p.price) as revenue
from order_items o
join products p on p.product_id = o.product_id
group by o.order_id;

-- 8.Count orders placed by each customer
select c.customer_id,c.customer_name, count(o.order_id) as tOrders
from customers c
join orders o on c.customer_id = o.customer_id
group by c.customer_id;

---------------------------------------------------
-- ⭐ MEDIUM QUERIES (6–10)
---------------------------------------------------

-- 1.Compare current order amount vs previous order (per customer)
-- 📌 Learn: LAG()
select o.customer_id,o.order_id,o.order_date, oi.quantity*p.price as 
total_amount,
lag (order_date) over(partition by o.customer_id order by
 o.order_date) as prev_ord_date,
lag (oi.quantity*p.price) over(partition by o.customer_id order by
 o.order_date) as prev_amt
from orders o
join order_items oi on o.order_id =oi.order_id
join products p on p.product_id = oi.product_id;

-- 2.Show each order's total and average order total
select distinct o.order_id,
sum(o.quantity*p.price) over(partition by order_id) as oTotal,
avg(o.quantity*p.price) over () as avgTotal
from order_items o
join products p on o.product_id = p.product_id;

-- 3.Find orders where total > overall average
select o.order_id,
sum(o.quantity*p.price) as oTotal
from order_items o
join products p on o.product_id=p.product_id
group by o.order_id
having oTotal > (select avg(o1.quantity*p1.price)
from order_items o1 join products p1 
on o1.product_id=p1.product_id);
 
 -- 4.Find next order placed by customer
 select customer_id,order_id,order_date,timestampdiff
(day,order_date,nxtOrderDate) as dayDiff from(
select customer_id,order_id,order_date,
lead(order_date) over(partition by customer_id
order by order_date) as nxtOrderDate
from orders)t;

-- 5.Rank customers by total spend
select customer_id,customer_name,total_spend,
rank () over (order by total_spend desc) as cRank
from (
select c.customer_id, c.customer_name,
sum(oi.quantity*p.price) as total_spend
from customers c
join orders o on o.customer_id = c.customer_id
join order_items oi on oi.order_id = o.order_id
join products p on p.product_id = oi.product_id
group by c.customer_id
)t;

-- 6) Total revenue per product
select p.product_id,p.product_name,
sum(o.quantity*p.price) as tRev
from products p 
join order_items o on p.product_id = o.product_id
group by p.product_id;

-- 7) Avg revenue per customer using window function
select distinct c.customer_id,c.customer_name,
avg(oi.quantity*p.price) over (partition by c.customer_id ) as avgRev
from customers c
join orders o on o.customer_id = c.customer_id
join order_items oi on oi.order_id = o.order_id
join products p on p.product_id = oi.product_id;

-- 8) Running total of order count per rep (Window Function)
select r.rep_id,r.rep_name,o.order_id,o.order_date,
row_number() over (partition by r.rep_id order by o.order_date) as running_total
from orders o
join sales_rep r on o.rep_id = r.rep_id;

-- 9) LAG() to compare customer’s previous order date
select c.customer_id,c.customer_name,o.order_date as currOrdDate,
lag(o.order_date) over (partition by c.customer_id order by order_date) as prevOrdDate
from customers c
join orders o on o.customer_id = c.customer_id;

-- 10) Correlated subquery: customers who spent above overall average
select c.customer_id,c.customer_name,
sum(oi.quantity*p.price) as tSpend
from customers c
join orders o on o.customer_id=c.customer_id
join order_items oi on o.order_id = oi.order_id
join products p on p.product_id = oi.product_id
group by customer_id
having tSpend >
( select avg (o1.quantity*p1.price) from order_items o1
join products p1 on p1.product_id = o1.product_id);

-- 11) Product-wise performance with LEAD() + % Contribution + Ranking
select p.product_id,p.product_name,o.order_date,
lead(o.order_date) over (partition by p.product_id order by order_date) as leadDate
from order_items oi
join orders o on o.order_id = oi.order_id
join products p on p.product_id = oi.product_id;

-- 1. Exercise: Customer Spend Change Analysis Task
-- You are working in a Retail Data Warehouse. Management wants to understand:

-- 1.How much each customer has spent in total
-- Calculate total spending per customer
select c.customer_id,c.customer_name,
sum(oi.quantity*p.price)  as total_spend
from customers c
join orders o on o.customer_id = c.customer_id
join order_items oi on o.order_id = oi.order_id
join products p on p.product_id = oi.product_id
group by customer_id;

-- 2. Who is spending more or less than others
-- Use window function to fetch previous customer’s total
select customer_id,customer_name,total_spend,
lag(total_spend) over (order by customer_id) as prevCustTotal
from
(select c.customer_id,c.customer_name ,
sum(oi.quantity*p.price) as total_spend
from customers c 
join orders o on o.customer_id = c.customer_id
join order_items oi on oi.order_id = o.order_id
join products p on p.product_id = oi.product_id
group by o.customer_id)t;

 -- 3.Change in spend between customers when sorted from highest → lowest
 -- Find difference (change) from previous customer’s spending
select customer_id,customer_name,total_spend,prevCustTotal,
(total_spend-prevCustTotal) as SpendDiff from
(select c.customer_id,c.customer_name,
sum(oi.quantity*p.price) as total_spend,
lag(sum(oi.quantity*p.price)) over(order by c.customer_id desc) as prevCustTotal
from customers c
join orders o on o.customer_id=c.customer_id
join order_items oi on oi.order_id = o.order_id
join products p on p.product_id = oi.product_id
group by c.customer_id)t;

-- 2. Revenue Change Analysis
--  Exercise 1 — Daily Revenue Change (Overall) Task
-- Management wants to monitor sales trend daily:
-- Total daily revenue
-- Previous day revenue
-- Change compared to yesterday
-- Key Function: LAG()
-- Expected Output Columns
-- | sale_date | daily_revenue | previous_day_revenue | revenue_change |
select sale_date,daily_revenue,previous_day_revenue,
(daily_revenue - previous_day_revenue) as revenue_change from
(select o.order_date as sale_date,
sum(oi.quantity*p.price) as daily_revenue,
lag(sum(oi.quantity*p.price)) over (order by o.order_date) as previous_day_revenue
from orders o 
join order_items oi on o.order_id = oi.order_id
join products p on p.product_id = oi.product_id
group by o.order_date)t;