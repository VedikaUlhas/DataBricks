use day2_4;

select c.city, count(o.order_id) as noOfOrd
from orders o
join customers c on c.customer_id = o.customer_id
group by c.city;

select * from products 
where price >10000
order by price desc;

select * from customers where city='Delhi';

select p.product_id,p.product_name,sum(oi.quantity)
from products p
join order_items oi on p.product_id = oi.product_id
group by p.product_id;

select r.rep_id, count(o.order_id) as noOfOrd
from orders o
join sales_rep r on r.rep_id = o.rep_id
group by rep_id
having noOfOrd >2;

select c.customer_id, c.customer_name ,count(o.order_id) as noOfOrd
from customers c
join orders o on o.customer_id = c.customer_id
group by c.customer_id
having noOfOrd>2;

select oi.order_id,sum(oi.quantity*p.price) as rev
from order_items oi
join products p on p.product_id = oi.product_id
group by oi.order_id;

select c.customer_id,c.customer_name,count(o.order_id) as noOfOrd
from customers c
join orders o on o.customer_id = c.customer_id
group by c.customer_id;

-- 1.Compare current order amount vs previous order (per customer)
select c.customer_id,c.customer_name,o.order_id,
(oi.quantity*p.price)  as curAmt,
lag(o.order_date) over(partition by c.customer_id order by o.order_date) as prevOrdDate,
lag(oi.quantity*p.price) over(partition by c.customer_id order by o.order_date) as prevAmt
from customers c
join orders o on o.customer_id=c.customer_id
join order_items oi on oi.order_id = o.order_id
join products p on p.product_id = oi.product_id;

-- 2.Show each order's total and average order total
select distinct oi.order_id,
sum(oi.quantity*p.price) over(partition by oi.order_id)as total,
avg(oi.quantity*p.price) over() as avgTotal
from order_items oi
join products p on oi.product_id = p.product_id;

-- 3.Find orders where total > overall average
select * from 
(select distinct oi.order_id, 
sum(oi.quantity*p.price) over(partition by oi.order_id)as total,
avg(oi.quantity*p.price) over() as avgTotal
from order_items oi
join products p on p.product_id = oi.product_id
)t
where total> avgTotal;

-- 4.Find next order placed by customer
select customer_id,customer_name,curOrdId,curDt,nxtId,nxtDt,
timestampdiff(day,curDt,nxtDt) as diff from
(select c.customer_id, c.customer_name,o.order_id as curOrdId,
o.order_date as curDt,
lead(o.order_id) over(partition by c.customer_id order by o.order_date) as nxtId,
lead(o.order_date) over (partition by c.customer_id order by o.order_date) as nxtDt
from customers c 
join orders o on c.customer_id = o.customer_id
)t;

-- 5.Rank customers by total spend
select customer_id,customer_name,totalSpend,
rank() over (order by totalSpend desc)  as cRank from
(
select distinct c.customer_id,c.customer_name,
sum(oi.quantity*p.price) over(partition by c.customer_id) as totalSpend
from customers c
join orders o on o.customer_id=c.customer_id
join order_items oi on o.order_id = oi.order_id
join products p on p.product_id = oi.product_id
)t;

-- 6) Total revenue per product
select p.product_id,p.product_name,sum(oi.quantity*p.price) as tRev
from products p
join order_items oi on oi.product_id = p.product_id
group by p.product_id;

-- 7) Avg revenue per customer using window function
select distinct c.customer_id,c.customer_name,
sum(oi.quantity*p.price) over(partition by c.customer_id) as revC,
avg(oi.quantity*p.price) over(partition by c.customer_id) as avgRevPc,
avg(oi.quantity*p.price) over() as OverAvgRev
from customers c
join orders o on o.customer_id = c.customer_id
join order_items oi on oi.order_id = o.order_id
join products p on p.product_id = oi.product_id; 

-- 8) Running total of order count per rep (Window Function)
-- Rep 1 → 1,2,3 progression
select r.rep_id,r.rep_name,o.order_id,o.order_date,
row_number() over(partition by r.rep_id order by o.order_date) as running_count
from sales_rep r
join orders o on o.rep_id=r.rep_id;

-- 9) LAG() to compare customer’s previous order date
select c.customer_id,c.customer_name,o.order_date as curDt,
lag(o.order_date) over(partition by c.customer_id order by order_date) as revDt
from customers c
join orders o on o.customer_id=c.customer_id;

-- 10) Correlated subquery: customers who spent above overall average
select * from 
(select c.customer_id,c.customer_name,
sum(oi.quantity*p.price) as total_spend,
avg(sum(oi.quantity*p.price)) over() as oAvgRev
from customers c
join orders o on o.customer_id = c.customer_id
join order_items oi on oi.order_id = o.order_id
join products p on p.product_id = oi.product_id
group by c.customer_id) t
where total_spend>oAvgRev;