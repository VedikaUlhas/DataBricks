create table DimCustomer_SCD (
customerkey int primary key auto_increment,
customerid int,
customerName varchar(100),
city varchar (50),
StartDate date,
EndDate date,
CurrentFlag char(1)
);

insert into DimCustomer_SCD 
(CustomerId, customerName,City,StartDate,EndDate,CurrentFlag)
values (101,'John','Delhi','2022-01-01',NULL,'Y');

set sql_safe_updates=0;
update dimCustomer_SCD
set city = 'Mumbai'
where CustomerId = 101;

update dimCustomer_SCD
set endDate = '2023-03-01', CurrentFlag ='N'
where CustomerId =101 and CurrentFlag = 'Y';

insert into dimCustomer_scd
(CustomerId,CustomerName,City,StartDate,EndDate,CurrentFlag)
values (101,'John','Mumbai','2023-03-02',NULL,'Y');

alter table dimCustomer_scd add column PrevCity varchar(50);

update dimCustomer_scd
set prevCity ='Delhi',city='Bangalore'
where CustomerId =101 and currentFlag ='Y';

select * from dimCustomer_SCD order by CustomerKey;