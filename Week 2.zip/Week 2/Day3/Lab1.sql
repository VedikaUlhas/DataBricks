create database if not exists ShopEasy_DB;
use ShopEasy_DB;

create table Customers (
Customer_id int primary key auto_increment,
FirstName varchar(50),
LastName varchar(50),
Email varchar(100),
City varchar(50)
);

create table products(
ProductId int primary key auto_increment,
ProductName varchar(100),
Category varchar(50),
UnitPrice decimal(10,2)
);

create table Orders(
OrderId int primary key auto_increment,
OrderDate date,
Customer_Id int,
foreign key (customer_Id) references Customers(Customer_Id)
);

create table OrderDetails(
OrderDetailId int primary key auto_increment,
orderId int,
ProductId int,
Quantity int,
foreign key (OrderId) references orders(orderId),
foreign key (ProductId) references Products(ProductId)
);

insert into Customers (FirstName, LastName, Email, City) values
('Amit','Sharma','amit@shop.com','Delhi'),
('Neha','Verma','neha@shop.com','Mumbai');

insert into Products (Productname, Category,UnitPrice) values
('Laptop','Electronics',65000),
('Mouse','Electronics',800),
('Shoes','Fashion',2500);

insert into orders (orderdate, customer_Id) values
('2025-10-01',1),
('2025-10-02',2);

insert into OrderDetails (OrderId,Productid,quantity) values
(1,1,1),(1,2,2),(2,3,1);

select o.orderid,c.firstName,p.productName,od.quantity,p.unitPrice
from orders o
join customers c on o.customer_id = c.customer_id
join OrderDetails od on o.orderId = od.orderid
join products p on od.productId = p.productId;

Create database if not exists ShopEasy_DW;
use ShopEasy_DW;

create table DimCustomer (
CustomerKey int primary key auto_increment,
customer_id int,
CustomerName varchar(100),
City varchar(50)
);

create table DimProduct (
ProductKey int primary key auto_increment,
ProductId int,
ProductName varchar(100),
Category varchar(50)
);

create table DimDate (
DateKey int primary key auto_increment,
fullDate date,
year int,
month int,
day int
);

create table FactSales (
FactId int primary key auto_increment,
Datekey int,
CustomerKey int,
ProductKey int,
Quantity int,
totalAmount decimal (10,2),
foreign key (Datekey) references Dimdate(datekey),
foreign key (ProductKey) references DimProduct (ProductKey)
);

insert into DimCustomer (customer_id, customerName,city)
values (1,'Amit Sharma','Delhi'),(2,'Neha Verma','Mumbai');

insert into DimProduct (ProductId,productName,Category)
values (1,'Laptop','Electronics'),(2,'Mouse','Electronics'),(3,'Shoes','Fashion');

insert into dimDate (FullDate,year,month,day)
values ('2025-10-01',2025,10,1),('2025-10-02',2025,10,2);

insert into FactSales (DateKey, CustomerKey,ProductKey, Quantity,TotalAmount)
values (1,1,1,1,65000),
(1,1,2,2,1600),
(2,2,3,1,2500);

select d.fullDate,c.customerName,p.productName,
f.quantity,f.totalAmount
from factSales f
join dimCustomer c on f.customerKey = c.customerkey
join DimProduct p on f.productkey = p.productkey
join dimdate d on f.datekey = d.datekey;

