create database if not exists ShopEasy_Profile;
use ShopEasy_Profile;

create table customers (
customerid int primary key,
fullname varchar(100),
email varchar(120),
phone varchar(20),
city varchar(50),
country varchar(50)
);

insert into Customers values 
(1,'Amit Sharma','amit@shop.com','9876543210','Delhi','India'),
(2,'Neha Verma','neha@shop.com',' ','mumbai','india'),
(3,'Ravi Kumar',NULL,'9567843210','Bangalore','India'),
(4,'Amit Sharma','amit@sharma.com','9876543210','Delhi','India'),
(5,NULL,'john@shop.com','9999999999','Chennai','India');

select count(*) as TotalRecords from customers;

select 
sum(case when fullname is null or fullname=' ' then 1 end) as nullNames,
sum(case when email is null or email=' ' then 1 end) as nullEmails,
sum(case when phone is null or trim(phone)=' ' then 1 end) as nullPhones
from customers;

select fullName,email,count(*) as DupCount
from customers
group by fullName,email
having count(*) >1;

select distinct country from customers;

update customers
set
fullName = trim(fullName),
city = concat(trim(city)),
country = upper(trim(country));

update customers 
set phone = null
where trim(phone) =' ';

DELETE FROM customers
WHERE CustomerId NOT IN (
    SELECT customer_id_to_keep
    FROM (
        SELECT MIN(CustomerId) AS customer_id_to_keep
        FROM customers
        GROUP BY fullName, email
    ) AS temp_customers
);

select count(*) as cleanCount,count(distinct email) as uniqueEmails from customers;

select * from Customers where length(Phone)<10 or length(phone)>12;

update Customers set country='India' where country is null;
update customers set fullName='Unknown Customer' where FullName is null;

select 
count(*) as total,
count(distinct email) as UniqueEmails,
sum(case when city is null then 1 end) as NullCities
from customers;