use cricketdb;

EXPLAIN 
SELECT p.full_name, b.runs
FROM players p
JOIN batting b ON p.player_id = b.player_id
WHERE p.country = 'India'
ORDER BY b.runs DESC
LIMIT 5;

show tables;
create index cIndex on players(country);


CREATE TEMPORARY TABLE temp_sr AS
SELECT player_id, strike_rate
FROM batting
ORDER BY strike_rate DESC
LIMIT 10;

SELECT t.player_id, p.full_name, t.strike_rate
FROM temp_sr t
JOIN players p ON p.player_id = t.player_id;

show tables;

use ltim;
select * from emp;

with dept_avg as (select deptno,
avg(sal) as avg_sal from emp
group by deptno) select * from dept_avg;

select * from dept_avg;

select * from batting;

select p.full_name, p.country,b.runs,b.batting_avg
from players p
inner join  batting b on p.player_id = b.player_id
where batting_avg >= 40
and b.runs > 5000
order by batting_avg desc
limit 5;

with top_batsmen as (
select player_id,batting_avg,runs
from batting
where format = 'ODI'
and batting_avg >=40
order by batting_avg desc
limit 5
)
select p.full_name,p.country,
t.runs,t.batting_avg
from top_batsmen t
join players p on p.player_id = t.player_id;

with indian_batsmen as(
select p.player_id,b.runs,b.batting_avg
from batting b
inner join players p on p.player_id = b.player_id
where p.country ='India'
)
select 
(select count(*) from indian_batsmen where batting_avg>50) as elite,
(select count(*) from indian_batsmen where runs>8000) as legends;

create temporary table temp_tbl as(
select p.player_id,runs,b.batting_avg
from batting b
inner join players p on p.player_id = b.player_id
where country = 'India'
 );
 
 select count(*) from temp_tbl
 where runs >8000;
 
 select * from players;
 update batting set runs = 9000 where player_id = 1003;

use ltim;
select * from emp;

WITH RECURSIVE emp_hierarchy AS (
    SELECT 
        empno,
        ename,
        job,
        mgr,
        0 AS level
    FROM emp
    WHERE mgr IS NULL   -- KING (PRESIDENT)
    UNION ALL
    SELECT 
        e.empno,
        e.ename,
        e.job,
        e.mgr,
        h.level + 1
    FROM emp e
    JOIN emp_hierarchy h 
        ON e.mgr = h.empno
)
SELECT * 
FROM emp_hierarchy
ORDER BY level, mgr, empno;

WITH RECURSIVE manager_chain AS (
    SELECT 
        empno,
        ename,
        mgr,
        0 AS level
    FROM emp
    WHERE empno = 7876   -- ADAMS
    UNION ALL
    SELECT 
        e.empno,
        e.ename,
        e.mgr,
        mc.level + 1
    FROM emp e
    JOIN manager_chain mc
        ON e.empno = mc.mgr
)
SELECT * FROM manager_chain;

WITH RECURSIVE sub_tree AS (
    SELECT 
        empno,
        mgr,
        empno AS root_manager
    FROM emp

    UNION ALL

    SELECT 
        e.empno,
        e.mgr,
        st.root_manager
    FROM emp e
    JOIN sub_tree st ON e.mgr = st.empno
)
SELECT 
    root_manager AS manager_empno,
    COUNT(*) - 1 AS total_subordinates
FROM sub_tree
GROUP BY root_manager
ORDER BY total_subordinates DESC;















use ltim;
select * from players;

with old_players as (select player_id
from players where active =0)
delete from players where player_id in 
(select player_id from old_players);



