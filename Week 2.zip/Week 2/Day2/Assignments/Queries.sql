create database cod8;
use cod8;

create table dim_customer(
customer_key int primary key,
customer_name varchar(100),
region varchar(50),
segment varchar(50)
);

create table dim_product(
product_key int primary key,
product_name varchar(100),
category varchar (50),
sub_category varchar(50)
);

create table dim_date(
date_key int primary key,
full_date date,
day int,
month int,
quarter int,
year int
);

create table fact_sales(
sales_key int primary key,
date_key int,
customer_key int,
product_key int,
quantity_sold int,
sales_amount decimal(10,2),
foreign key (date_key) references dim_date(date_key),
foreign key (customer_key) references dim_customer (customer_key),
foreign key(product_key) references dim_product(product_key)
);

insert into dim_customer values 
(1,'Alice Corp','North','Enterprise'),
(2,'Beta LLC','South','SMB');

insert into dim_product values
(1,'Laptop Pro','Electronics','Computers'),
(2,'Office Chair','Furniture','Chairs');

insert into dim_date values
(20250101,'2025-01-01',1,1,1,2025),
(20250102,'2025-01-02',2,1,1,2025);

insert into fact_sales values
(1,20250101,1,1,10,15000.00),
(2,20250102,2,2,5,1000.00);

select sum(sales_amount) as total_sales
from fact_sales;

select c.customer_name,sum(f.sales_amount) as total_sales
from fact_sales f
join dim_customer c on f.customer_key = c.customer_key
group by c.customer_name;

select p.category,sum(f.sales_amount) as total_sales
from fact_sales f
join dim_product p on f.product_key = p.product_key
group by p.category;

select d.full_date, sum(f.sales_amount) as daily_sales
from fact_sales f
join dim_date d on f.date_key = d.date_key
group by d.full_date
order by d.full_date;