use information_schema;
show tables;
select * from columns;

use performance_schema;
show tables;
