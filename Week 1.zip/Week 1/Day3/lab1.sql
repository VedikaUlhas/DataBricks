select * from products;
select * from sales;

select  * from sales where qty >
(select avg(qty) from sales)
order by sale_id;

select sale_id,product_id,qty,discount_pct,sale_date,store,
(select AVG(unti_price) from products) As avg_unit_price
from sales order by sale_id;

select * from sales where product_id in
(select product_id from products where category = 'Stationary');

select * from sales where product_id not in
(select product_id from products where category = 'Electronics');

select * from sales s
where qty >
(select avg(qty) from sales where store=s.store)
order by store,sale_id;

select * from sales s 
where exists(
select 1 from products p where p.product_id=s.product_id 
AND p.unti_price>1000
) order by sale_id;

select * from products p where not exists
(select 1 from sales s where s.product_id =p.product_id)
order by product_id;

select * from products 
where unti_price > any 
(select unti_price from products where category='Stationary')
order by unti_price desc,product_id;

select * from products where unti_price > ALL
(select unti_price from products where category='Stationary')
order by unti_price desc, product_id;

select * from products p 
where unti_price =(
select max(unti_price) from products where category =p.category
) order by category,product_id;

SELECT * from sales where product_id in 
(select product_id from products where unti_price >= 5000)
order by sale_id;

select * from sales 
where product_id not in 
(select product_id from products where category ='Accessories')
order by sale_id; 

