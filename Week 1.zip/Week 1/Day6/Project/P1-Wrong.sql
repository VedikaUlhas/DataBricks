DROP DATABASE IF EXISTS de_project_e;
CREATE DATABASE de_project_e;
USE de_project_e;

CREATE TABLE accounts (
  acct_id INT AUTO_INCREMENT PRIMARY KEY,
  acct_no VARCHAR(50) UNIQUE,
  acct_holder VARCHAR(100),
  acct_type VARCHAR(20),
  opened_date DATE,
  status VARCHAR(20),
  branch VARCHAR(100),
  balance DECIMAL(15,2),
  phone VARCHAR(30),
  email VARCHAR(150),
  CHECK (status IN ('ACTIVE','CLOSED','SUSPENDED'))
) ENGINE=InnoDB;

INSERT INTO accounts(acct_no,acct_holder,acct_type,opened_date,status,branch,balance,phone,email) VALUES
('ACCT1001','Rohan K','Savings','2018-01-01','ACTIVE','Delhi Main',150000,'+919900000001','rohan.k@example.com'),
('ACCT1002','Sana P','Savings','2019-02-02','ACTIVE','Mumbai West',25000,'+919900000002','sana.p@example.com'),
('ACCT1003','Tarun M','Current','2017-03-03','SUSPENDED','Bengaluru East',500000,'+919900000003','tarun.m@example.com'),
('ACCT1004','Uma D','Savings','2020-04-04','ACTIVE','Kolkata Central',12000,'+919900000004','uma.d@example.com'),
('ACCT1005','Vikram S','Savings','2016-05-05','ACTIVE','Chennai South',78000,'+919900000005','vikram.s@example.com'),
('ACCT1006','Wendy R','Current','2015-06-06','ACTIVE','Pune North',900000,'+919900000006','wendy.r@example.com'),
('ACCT1007','Xavier L','Savings','2021-07-07','ACTIVE','Hyderabad',4500,'+919900000007','xavier.l@example.com'),
('ACCT1008','Yash T','Current','2014-08-08','ACTIVE','Ahmedabad',1200000,'+919900000008','yash.t@example.com'),
('ACCT1009','Zoe F','Savings','2013-09-09','CLOSED','Noida',0,'+919900000009','zoe.f@example.com'),
('ACCT1010','Aman G','Savings','2012-10-10','ACTIVE','Lucknow',67000,'+919900000010','aman.g@example.com'),
('ACCT1011','Bina H','Current','2011-11-11','ACTIVE','Gurgaon',300000,'+919900000011','bina.h@example.com'),
('ACCT1012','Chetan I','Savings','2010-12-12','ACTIVE','Bhopal',55000,'+919900000012','chetan.i@example.com'),
('ACCT1013','Divya J','Savings','2022-01-01','ACTIVE','Patna',23000,'+919900000013','divya.j@example.com'),
('ACCT1014','Eshan K','Current','2019-02-02','ACTIVE','Raipur',980000,'+919900000014','eshan.k@example.com'),
('ACCT1015','Fatima L','Savings','2018-03-03','ACTIVE','Visakhapatnam',1200,'+919900000015','fatima.l@example.com'),
('ACCT1016','Gaurav M','Savings','2017-04-04','ACTIVE','Mangalore',43000,'+919900000016','gaurav.m@example.com'),
('ACCT1017','Hema N','Current','2016-05-05','ACTIVE','Dehradun',670000,'+919900000017','hema.n@example.com'),
('ACCT1018','Ishan O','Savings','2020-06-06','ACTIVE','Shimla',8900,'+919900000018','ishan.o@example.com'),
('ACCT1019','Jaya P','Savings','2015-07-07','ACTIVE','Jammu',154000,'+919900000019','jaya.p@example.com'),
('ACCT1020','Kabir Q','Current','2014-08-08','ACTIVE','Bhubaneswar',210000,'+919900000020','kabir.q@example.com'),
('ACCT1021','Lata R','Savings','2013-09-09','ACTIVE','Guwahati',39000,'+919900000021','lata.r@example.com'),
('ACCT1022','Mohan S','Savings','2012-10-10','ACTIVE','Indore',72000,'+919900000022','mohan.s@example.com');

CREATE TABLE transactions (
  tx_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  acct_id INT,
  tx_type VARCHAR(20), -- CREDIT / DEBIT
  amount DECIMAL(12,2),
  tx_date DATETIME,
  channel VARCHAR(50),
  narrative VARCHAR(200),
  balance_after DECIMAL(15,2),
  merchant VARCHAR(100),
  location VARCHAR(100),
  FOREIGN KEY (acct_id) REFERENCES accounts(acct_id)
) ENGINE=InnoDB;

INSERT INTO transactions(acct_id,tx_type,amount,tx_date,channel,narrative,balance_after,merchant,location) VALUES
(1,'DEBIT',5000,'2024-11-18 09:10:00','ATM','Cash withdrawal',145000,'ATM-Delhi','Connaught Place'),
(1,'CREDIT',20000,'2024-11-17 10:00:00','NEFT','Salary',150000,'Company Ltd','Mumbai'),
(2,'DEBIT',2000,'2024-11-15 11:00:00','POS','Grocery',23000,'LocalMart','Mumbai'),
(3,'DEBIT',15000,'2024-11-14 08:30:00','INTERNET','Bill Payment',485000,'Utilities','Delhi'),
(4,'CREDIT',5000,'2024-11-14 11:20:00','UPI','Refund',17000,'ECom','Kolkata'),
(5,'DEBIT',1200,'2024-11-13 09:00:00','POS','Café',76800,'CafeHouse','Chennai'),
(6,'DEBIT',500000,'2024-11-12 10:00:00','RTGS','Property',400000,'RealEstate','Pune'),
(7,'CREDIT',10000,'2024-11-11 12:00:00','NEFT','Gift',14500,'Friend','Hyderabad'),
(8,'DEBIT',20000,'2024-11-10 13:00:00','POS','Electronics',1180000,'ElectroStore','Ahmedabad'),
(9,'DEBIT',100,'2024-11-09 14:00:00','ATM','Cash', -100 ,'ATM-Noida','Noida'), -- intentionally bad balance_after for validation
(10,'CREDIT',7000,'2024-11-08 15:00:00','NEFT','Salary',74000,'Company','Lucknow'),
(11,'DEBIT',15000,'2024-11-07 16:00:00','POS','Jewellery',285000,'GoldShop','Gurgaon'),
(12,'DEBIT',5000,'2024-11-06 17:00:00','UPI','Donation',50050,'Charity','Bhopal'),
(13,'CREDIT',30000,'2024-11-05 09:00:00','NEFT','Sale',53000,'ECom','Patna'),
(14,'DEBIT',100000,'2024-11-04 10:00:00','RTGS','Investment',880000,'Broker','Raipur'),
(15,'DEBIT',200,'2024-11-03 11:00:00','POS','Stationery',1000,'Stationers','Vizag'),
(16,'CREDIT',5000,'2024-11-02 12:00:00','NEFT','Transfer',48000,'Friend','Mangalore'),
(17,'DEBIT',50000,'2024-11-01 13:00:00','RTGS','Business',620000,'Supplier','Dehradun'),
(18,'DEBIT',300,'2024-10-31 14:00:00','POS','Groceries',8600,'Grocery','Shimla'),
(19,'CREDIT',25000,'2024-10-30 15:00:00','NEFT','Sale',179000,'Market','Jammu'),
(20,'DEBIT',12000,'2024-10-29 16:00:00','INTERNET','EMI',198000,'Bank','Bhubaneswar'),
(21,'CREDIT',5000,'2024-10-28 17:00:00','NEFT','Salary',44000,'Company','Guwahati'),
(22,'DEBIT',7000,'2024-10-27 09:00:00','POS','Electronics',65000,'Electro','Indore'),
(1,'DEBIT',15000,'2024-10-26 10:00:00','INTERNET','Bill',130000,'Utilities','Delhi'),
(2,'DEBIT',500,'2024-10-25 11:00:00','POS','Coffee',22500,'Cafe','Mumbai'),
(3,'CREDIT',25000,'2024-10-24 12:00:00','NEFT','Refund',510000,'ECom','Delhi'),
(4,'DEBIT',2000,'2024-10-23 13:00:00','ATM','Cash',15000,'ATM-Kolkata','Kolkata'),
(5,'DEBIT',3000,'2024-10-22 14:00:00','POS','Repair',73800,'RepairCo','Chennai'),
(6,'CREDIT',100000,'2024-10-21 15:00:00','NEFT','Investment Return',500000,'InvestCo','Pune'),
(7,'DEBIT',3500,'2024-10-20 16:00:00','POS','Fuel',11000,'PetrolPump','Hyderabad'),
(8,'DEBIT',6000,'2024-10-19 17:00:00','UPI','Bill',1174000,'BillingCo','Ahmedabad'),
(9,'CREDIT',300,'2024-10-18 09:00:00','CASHDEP','Deposit',- -100,'Branch','Noida'), -- intentionally wrong to show validation
(10,'DEBIT',2000,'2024-10-17 10:00:00','POS','Groceries',72000,'Grocery','Lucknow'),
(11,'CREDIT',10000,'2024-10-16 11:00:00','NEFT','Payment',295000,'Client','Gurgaon'),
(12,'DEBIT',4000,'2024-10-15 12:00:00','POS','Electronics',46050,'Shop','Bhopal'),
(13,'DEBIT',5000,'2024-10-14 13:00:00','ATM','Cash',48000,'ATM-Patna','Patna');

-- Data Validation
-- Email validation
select acct_id,acct_no,email from accounts 
where email not like '%@%.___';

-- Phone validation
select acct_id,acct_no,phone 
from accounts
where length(phone) !=13 and 
phone not like '+91%'; 

-- Checking Negative or invalid balance

select a.acct_id,a.acct_no,a.balance,t.balance_after
from accounts a
inner join transactions t on a.acct_id=t.acct_id
where a.balance != t.balance_after;


-- Account opening date validation
select acct_id,acct_no,opened_date
from accounts
where opened_date like '____-__-__';

-- Find missing details
select acct_no,acct_holder,phone,email 
from accounts where acct_no is null

