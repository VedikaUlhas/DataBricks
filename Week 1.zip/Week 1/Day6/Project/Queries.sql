DROP DATABASE IF EXISTS de_project_c;
CREATE DATABASE de_project_c;
USE de_project_c;

CREATE TABLE subscribers (
  sub_id INT AUTO_INCREMENT PRIMARY KEY,
  msisdn VARCHAR(20) UNIQUE,
  full_name VARCHAR(100),
  region VARCHAR(50),
  plan VARCHAR(50),
  install_date DATE,
  email VARCHAR(150),
  is_active TINYINT(1) DEFAULT 1,
  address VARCHAR(200),
  billing_cycle INT,
  CHECK (is_active IN (0,1))
) ENGINE=InnoDB;

-- 20 subscribers
INSERT INTO subscribers(msisdn,full_name,region,plan,install_date,email,is_active,address,billing_cycle) VALUES
('+919000000001','A Arora','Delhi','Postpaid','2020-01-01','a.arora@example.com',1,'Connaught Place, Delhi',1),
('+919000000002','B Bhat','Mumbai','Prepaid','2021-05-05','b.bhat@example.com',1,'Andheri, Mumbai',15),
('+919000000003','C Chawla','Bengaluru','Postpaid','2019-03-03','c.chawla@example.com',1,'MG Road, Bengaluru',1),
('+919000000004','D Dutta','Kolkata','Prepaid','2022-07-07','d.dutta@example.com',1,'Park Street, Kolkata',10),
('+919000000005','E Edwin','Chennai','Postpaid','2018-08-08','e.edwin@example.com',1,'Anna Nagar, Chennai',1),
('+919000000006','F Fernandes','Pune','Prepaid','2023-09-09','f.fernandes@example.com',1,'Koregaon Park, Pune',20),
('+919000000007','G Goyal','Hyderabad','Postpaid','2017-04-04','g.goyal@example.com',1,'Banjara Hills, Hyderabad',1),
('+919000000008','H Hussain','Ahmedabad','Prepaid','2020-06-06','h.hussain@example.com',1,'Navrangpura, Ahmedabad',5),
('+919000000009','I Iyer','Surat','Prepaid','2021-11-11','i.iyer@example.com',1,'Varachha, Surat',10),
('+919000000010','J Jain','Noida','Postpaid','2019-12-12','j.jain@example.com',1,'Sector 18, Noida',1),
('+919000000011','K Kapoor','Faridabad','Prepaid','2020-02-02','k.kapoor@example.com',1,'Sector 16, Faridabad',20),
('+919000000012','L Lal','Gurgaon','Postpaid','2018-05-05','l.lal@example.com',1,'DLF Phase 1, Gurgaon',1),
('+919000000013','M Mehra','Bhopal','Prepaid','2022-03-03','m.mehra@example.com',1,'Arera Hills, Bhopal',15),
('+919000000014','N Nanda','Patna','Prepaid','2023-01-15','n.nanda@example.com',1,'Kankarbagh, Patna',5),
('+919000000015','O Oberoi','Lucknow','Postpaid','2016-06-06','o.oberoi@example.com',1,'Hazratganj, Lucknow',1),
('+919000000016','P Prasad','Bhubaneswar','Prepaid','2021-07-07','p.prasad@example.com',1,'Saheed Nagar, Bhubaneswar',10),
('+919000000017','Q Qureshi','Indore','Postpaid','2019-09-09','q.qureshi@example.com',1,'MG Road, Indore',1),
('+919000000018','R Rao','Agra','Prepaid','2020-10-10','r.rao@example.com',1,'Shahganj, Agra',20),
('+919000000019','S Sinha','Amritsar','Postpaid','2022-11-11','s.sinha@example.com',1,'Hall Bazaar, Amritsar',1),
('+919000000020','T Thomas','Kochi','Prepaid','2021-08-08','t.thomas@example.com',1,'Marine Drive, Kochi',15);

CREATE TABLE cdr (
  cdr_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  msisdn VARCHAR(20),
  call_start DATETIME,
  call_end DATETIME,
  duration_sec INT,
  called_number VARCHAR(20),
  call_type VARCHAR(20), -- voice, sms, data
  mcc_mnc VARCHAR(20),
  cell_id VARCHAR(50),
  roam_flag TINYINT(1) DEFAULT 0,
  FOREIGN KEY (msisdn) REFERENCES subscribers(msisdn)
) ENGINE=InnoDB;

-- 30 sample CDRs
INSERT INTO cdr(msisdn,call_start,call_end,duration_sec,called_number,call_type,mcc_mnc,cell_id,roam_flag) VALUES
('+919000000001','2024-11-18 09:00:00','2024-11-18 09:10:00',600,'+919111111111','voice','404-10','cell-1001',0),
('+919000000002','2024-11-18 10:00:00','2024-11-18 10:05:00',300,'+919222222222','voice','404-11','cell-1002',0),
('+919000000003','2024-11-18 11:00:00','2024-11-18 11:02:00',120,'+919333333333','voice','404-12','cell-1003',0),
('+919000000004','2024-11-17 09:00:00','2024-11-17 09:03:00',180,'+919444444444','sms','404-10','cell-1001',0),
('+919000000005','2024-11-17 12:00:00','2024-11-17 12:20:00',1200,'+919555555555','voice','404-11','cell-1004',1),
('+919000000006','2024-11-16 08:00:00','2024-11-16 08:05:00',300,'+919666666666','voice','404-12','cell-1005',0),
('+919000000007','2024-11-16 13:00:00','2024-11-16 13:30:00',1800,'+919777777777','data','404-10','cell-1006',0),
('+919000000008','2024-11-15 14:00:00','2024-11-15 14:15:00',900,'+919888888888','voice','404-11','cell-1007',0),
('+919000000009','2024-11-15 15:00:00','2024-11-15 15:01:00',60,'+919999999999','voice','404-12','cell-1008',0),
('+919000000010','2024-11-14 16:00:00','2024-11-14 16:30:00',1800,'+919101010101','voice','404-10','cell-1009',0),
('+919000000011','2024-11-13 17:00:00','2024-11-13 17:10:00',600,'+919202020202','voice','404-11','cell-1010',0),
('+919000000012','2024-11-12 18:00:00','2024-11-12 18:05:00',300,'+919303030303','voice','404-12','cell-1011',0),
('+919000000013','2024-11-11 19:00:00','2024-11-11 19:04:00',240,'+919404040404','sms','404-10','cell-1012',0),
('+919000000014','2024-11-10 20:00:00','2024-11-10 20:30:00',1800,'+919505050505','voice','404-11','cell-1013',0),
('+919000000015','2024-11-09 21:00:00','2024-11-09 21:15:00',900,'+919606060606','data','404-12','cell-1014',1),
('+919000000016','2024-11-08 22:00:00','2024-11-08 22:02:00',120,'+919707070707','voice','404-10','cell-1015',0),
('+919000000017','2024-11-07 23:00:00','2024-11-07 23:01:00',60,'+919808080808','voice','404-11','cell-1016',0),
('+919000000018','2024-11-06 07:00:00','2024-11-06 07:30:00',1800,'+919909090909','voice','404-12','cell-1017',1),
('+919000000019','2024-11-05 06:00:00','2024-11-05 06:05:00',300,'+919111111112','voice','404-10','cell-1018',0),
('+919000000020','2024-11-04 05:00:00','2024-11-04 05:07:00',420,'+919222222223','voice','404-11','cell-1019',0),
('+919000000001','2024-10-04 09:00:00','2024-10-04 09:05:00',300,'+919111111113','voice','404-10','cell-1020',0),
('+919000000002','2024-10-03 10:00:00','2024-10-03 10:06:00',360,'+919222222224','voice','404-11','cell-1021',0),
('+919000000003','2024-09-02 11:00:00','2024-09-02 11:01:00',60,'+919333333335','sms','404-12','cell-1022',0),
('+919000000004','2024-09-01 09:00:00','2024-09-01 09:20:00',1200,'+919444444446','voice','404-10','cell-1001',0),
('+919000000005','2024-08-27 12:00:00','2024-08-27 12:40:00',2400,'+919555555557','voice','404-11','cell-1004',1),
('+919000000006','2024-08-26 08:00:00','2024-08-26 08:02:00',120,'+919666666668','voice','404-12','cell-1005',0),
('+919000000007','2024-08-25 13:00:00','2024-08-25 13:10:00',600,'+919777777779','voice','404-10','cell-1006',0),
('+919000000008','2024-08-24 14:00:00','2024-08-24 14:09:00',540,'+919888888880','data','404-11','cell-1007',0),
('+919000000009','2024-08-23 15:00:00','2024-08-23 15:08:00',480,'+919999999991','voice','404-12','cell-1008',0);

CREATE TABLE tariffs (
  tariff_id INT AUTO_INCREMENT PRIMARY KEY,
  plan VARCHAR(50),
  monthly_fee DECIMAL(10,2),
  voice_rate_per_min DECIMAL(6,3),
  sms_rate DECIMAL(6,3),
  data_rate_per_mb DECIMAL(6,4),
  valid_from DATE,
  valid_to DATE,
  notes VARCHAR(200)
) ENGINE=InnoDB;

-- tariffs (20 rows not necessary; create 8 realistic)
INSERT INTO tariffs(plan,monthly_fee,voice_rate_per_min,sms_rate,data_rate_per_mb,valid_from,valid_to,notes) VALUES
('Postpaid Basic',199,0.50,0.05,0.002,'2019-01-01','2025-12-31',''),
('Postpaid Unlimited',799,0.00,0.00,0.000,'2021-01-01','2025-12-31','Unlimited data cap applies'),
('Prepaid Basic',0,0.60,0.06,0.003,'2018-01-01','2026-12-31','Pay per use'),
('Prepaid Saver',199,0.30,0.03,0.001,'2022-01-01','2025-12-31','Bundle discounts'),
('Corporate',999,0.10,0.01,0.0005,'2017-01-01','2025-12-31',''),
('Student',99,0.20,0.02,0.0008,'2020-01-01','2025-12-31','ID proof required'),
('International',1499,1.50,0.20,0.010,'2016-01-01','2025-12-31','Roaming included'),
('Data Only',299,0.00,0.00,0.0002,'2023-01-01','2025-12-31','For IoT devices');

select * from subscribers;

-- Data Validation & Profiling
-- Validate subscribers.msisdn format & uniqueness.
select sub_id,msisdn,full_name from subscribers 
where length(msisdn) = 13 and msisdn like '+91%';

select msisdn, count(msisdn) 
from subscribers
group by  msisdn
having count(msisdn) > 1;

-- Validate cdr.call_start, cdr.call_end, duration_sec consistency (script includes validation example).
select cdr_id,call_start,call_end ,duration_sec from cdr
where timestampdiff(second,call_start,call_end) != duration_sec;

-- Check cdr.call_type values (voice, sms, data) and roam_flag values.

select cdr_id,call_type
from cdr 
where lower(call_type) not in ('voice','sms','data');

select cdr_id,roam_flag
from cdr 
where roam_flag not in ('1','0');


-- Data Cleaning
-- Fix duration_sec mismatches vs TIMESTAMPDIFF(SECOND, call_start, call_end).
set sql_safe_updates =0;
UPDATE cdr 
SET duration_sec = TIMESTAMPDIFF(SECOND, call_start, call_end)
WHERE duration_sec != TIMESTAMPDIFF(SECOND, call_start, call_end);

-- Standardize mcc_mnc and cell_id labels.
UPDATE cdr 
SET mcc_mnc = UPPER(mcc_mnc), 
cell_id = UPPER(cell_id);
    
-- Remove or flag orphan cdr rows (FK to subscribers.msisdn should prevent orphans).
SELECT cdr_id, msisdn 
FROM cdr
WHERE msisdn NOT IN (SELECT msisdn FROM subscribers);

-- Constraints & Integrity
-- PK: subscribers.sub_id, cdr.cdr_id, tariffs.tariff_id.
-- FK: cdr.msisdn → subscribers.msisdn.
-- Add CHECK on is_active IN (0,1) (already present).

-- TRANSFORMATIONS
-- Example query to extract and compute transformed fields
SELECT
    cdr_id,
    msisdn,
    DATE(call_start) AS call_date, -- Extract call_date
    HOUR(call_start) AS call_hour, -- Extract call_hour
    duration_sec,
    CEIL(duration_sec / 60) AS call_minutes, -- Compute call_minutes (ceiling)
    call_type,
    roam_flag
FROM
    cdr;
    
    -- Total call duration by Region and Plan
SELECT
    s.region,
    s.plan,
    SUM(c.duration_sec) AS total_duration_sec,
    COUNT(c.cdr_id) AS total_cdrs
FROM
    cdr c
JOIN
    subscribers s ON c.msisdn = s.msisdn
GROUP BY 1, 2
ORDER BY 1, 2;

-- Calculate estimated charges for each CDR
SELECT
    c.cdr_id,
    c.msisdn,
    s.plan,
    c.call_type,
    c.duration_sec,
    t.voice_rate_per_min,
    t.sms_rate,
    t.data_rate_per_mb,
    -- Estimated Charge Calculation
    CASE c.call_type
        WHEN 'voice' THEN CEIL(c.duration_sec / 60) * t.voice_rate_per_min
        WHEN 'sms' THEN t.sms_rate -- Assuming 1 SMS per CDR for SMS type
        WHEN 'data' THEN (c.duration_sec / 1024) * t.data_rate_per_mb -- Assuming duration_sec is a proxy for KiloBytes (KB) of data, and 1MB = 1024 KB
        ELSE 0
    END AS estimated_charge
FROM
    cdr c
JOIN
    subscribers s ON c.msisdn = s.msisdn
JOIN
    tariffs t ON s.plan = t.plan
-- Add criteria to select the current valid tariff if necessary (e.g., AND c.call_start BETWEEN t.valid_from AND t.valid_to)
ORDER BY c.cdr_id
LIMIT 10;

-- Sub queries and anomaly detection
-- 1. Calculate the population average voice call duration
WITH Population_Avg AS (
    SELECT AVG(duration_sec) AS avg_duration
    FROM cdr
    WHERE call_type = 'voice'
),
-- 2. Calculate each subscriber's average voice call duration
Subscriber_Avg AS (
    SELECT
        msisdn,
        AVG(duration_sec) AS sub_avg_duration
    FROM
        cdr
    WHERE call_type = 'voice'
    GROUP BY msisdn
)
-- 3. Identify subscribers where their average is significantly higher than the population average
SELECT
    s.msisdn,
    s.full_name,
    sa.sub_avg_duration,
    pa.avg_duration AS population_avg
FROM
    Subscriber_Avg sa
JOIN
    subscribers s ON sa.msisdn = s.msisdn
CROSS JOIN
    Population_Avg pa
WHERE
    sa.sub_avg_duration > 2 * pa.avg_duration -- Anomaly threshold
ORDER BY sa.sub_avg_duration DESC;

-- Detect Roaming Usage Spikes (by Region/Date)

SELECT
    DATE(c.call_start) AS call_date,
    s.region,
    COUNT(c.cdr_id) AS roaming_events_count
FROM
    cdr c
JOIN
    subscribers s ON c.msisdn = s.msisdn
WHERE
    c.roam_flag = 1
GROUP BY 1, 2
HAVING
    COUNT(c.cdr_id) > 1 -- Threshold for a 'spike' (can be adjusted)
ORDER BY call_date DESC, roaming_events_count DESC;

-- Rolling 7-Day Call Volume per msisdn (Window Functions)

SELECT
    DATE(call_start) AS call_date,
    msisdn,
    COUNT(cdr_id) AS daily_call_count,
    SUM(COUNT(cdr_id)) OVER (
        PARTITION BY msisdn
        ORDER BY DATE(call_start)
        RANGE BETWEEN INTERVAL 6 DAY PRECEDING AND CURRENT ROW -- Rolling 7-day sum
    ) AS rolling_7_day_call_volume
FROM
    cdr
GROUP BY 1, 2
ORDER BY msisdn, call_date;

-- Masking and values

-- Create a view with masked MSISDN (showing only the last 4 digits) and Email (showing only the domain)
CREATE VIEW v_subscribers_masked AS
SELECT
    sub_id,
    CONCAT('*******', RIGHT(msisdn, 4)) AS masked_msisdn, -- Mask MSISDN
    full_name,
    region,
    plan,
    install_date,
    CONCAT('***@', SUBSTRING_INDEX(email, '@', -1)) AS masked_email, -- Mask Email
    is_active,
    address,
    billing_cycle
FROM
    subscribers
WITH CHECK OPTION;

 -- Ensures view is read-only for updates/inserts

-- Example query using the masked view
SELECT * FROM v_subscribers_masked LIMIT 5;

--  Performance

-- Add a composite index on msisdn and call_start for faster lookups and range queries
CREATE INDEX idx_cdr_msisdn_start ON cdr (msisdn, call_start);

-- Add an index on plan in subscribers for faster joins to tariffs table
CREATE INDEX idx_subscribers_plan ON subscribers (plan);

-- Business Query Tasks
-- INNER JOIN (all tables)
 -- Retrieve full CDR with subscriber details, circle/region, call type, duration, and timestamp.

select c.cdr_id,c.msisdn,s.full_name,s.region,c.call_type,
c.duration_sec 
from cdr c
inner join subscribers s on s.msisdn =c.msisdn;

-- JOIN + Aggregate
-- Compute total call duration per call_type (incoming, outgoing, missed).
select call_type, sum(duration_sec) 
from cdr
group by (call_type);

-- For each subscriber, retrieve their most recent call record.
select s.full_name,c.msisdn
from cdr c
inner join subscribers s on s.msisdn = c.msisdn
where c.call_end =
(select max(call_end) from cdr where msisdn = s.msisdn)
group by s.full_name,c.msisdn;


-- For each circle/region, find the latest call timestamp.
select s.region,c.call_end
from cdr c
inner join subscribers s on s.msisdn = c.msisdn
where c.call_end =
(select max(call_end) from cdr where msisdn = s.msisdn)
group by region,c.call_end;
 
-- Fetch all call records within the last 24 hours using DATE_SUB or INTERVAL.
select * from cdr where call_end >= now() - interval 24 hour;
