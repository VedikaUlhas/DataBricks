use cricketdb;

select * from players;

delete from players where player_id = 1003;